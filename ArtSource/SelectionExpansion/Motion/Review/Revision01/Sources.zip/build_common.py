from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,re,hashlib,math,sys,base64
import os
R=Path(os.environ["DUNGEON_MATCHER_PROJECT"]).resolve()
M=R/'ArtSource/SelectionExpansion/Motion'
O=Path(__file__).resolve().parent
O.mkdir(parents=True,exist_ok=True)
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,o):p.write_text(json.dumps(o,indent=2)+'\n',encoding='utf-8')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
clips=read(M/'clips.json')
ids={r['enemy']:r for r in read(R/'ArtSource/SelectionExpansion/ART_STILL_REVIEW/decisions.json')['approved']}
keep=lambda e,s:e in {'guild_ranger','nacre_duelist','ore_ram'} or (e,s) in {('guild_swordsman','basic'),('guild_bulwark','special'),('guild_chirurgeon','basic')}
edit=[c for c in clips if not keep(c['enemy'],c['state'])]
assert len(edit)==13

import struct,subprocess,shutil
libre=os.environ.get('LIBRESPRITE','libresprite')
def proof(im):return hashlib.sha256(im.tobytes()).hexdigest()
def export_editor(cels,times,folder):
 folder.mkdir(exist_ok=True,parents=True);doc=folder/'source.aseprite'
 # Feed the lossless RGBA sequence through the native editor. A temporary ASE file
 # permits exact durations, including a held pose with unchanged pixels.
 def pack(fmt,*v):return struct.pack('<'+fmt,*v)
 import zlib
 def chunk(kind,payload):return pack('IH',len(payload)+6,kind)+payload
 def string(x):return pack('H',len(x))+x
 layer=chunk(0x2004,pack('HHHHHHB',3,0,0,0,0,0,255)+bytes(3)+string(b'Character'))
 frames=[]
 for i,im in enumerate(cels):
  cel=chunk(0x2005,pack('HhhBH',0,0,0,255,2)+bytes(7)+pack('HH',*im.size)+zlib.compress(im.tobytes()))
  body=(layer if i==0 else b'')+cel
  frames.append(pack('IHHH',len(body)+16,0xF1FA,2 if i==0 else 1,times[i])+bytes(6)+body)
 header=bytearray(128);struct.pack_into('<IHHHHHIH',header,0,128+sum(map(len,frames)),0xA5E0,len(frames),*cels[0].size,32,1,times[0]);header[34:36]=bytes([1,1])
 src=folder/'registered.ase';src.write_bytes(header+b''.join(frames))
 subprocess.run([libre,'-b',str(src),'--save-as',str(doc)],check=True,capture_output=True)
 png=folder/'sheet.png';subprocess.run([libre,'-b',str(doc),'--sheet-type','horizontal','--sheet',str(png)],check=True,capture_output=True)
 out=Image.open(png).convert('RGBA');w,h=cels[0].size;assert out.size==(w*len(cels),h),(out.size,len(cels))
 blob=doc.read_bytes();offset=128;actual=[]
 for i,im in enumerate(cels):
  assert out.crop((i*w,0,(i+1)*w,h)).tobytes()==im.tobytes()
  actual.append(struct.unpack_from('<H',blob,offset+8)[0]);offset+=struct.unpack_from('<I',blob,offset)[0]
 assert actual==times
 src.unlink();return png,doc

def finish(c,frames,times,notes):
 # Preserve cue boundaries across the native edit, GIF and review player.
 ends=[0]
 for ms in times:ends.append(ends[-1]+ms)
 ticks=[((t+5)//10)*10 for t in ends]
 times=[b-a for a,b in zip(ticks,ticks[1:])]
 e=c['enemy'];s=c['state'];k=e+'_'+s;p=O/'Clips'/k
 original=Image.open(O/(k+'_input.png')).convert('RGBA')
 assert frames[0].tobytes()==original.tobytes() and frames[-1].tobytes()==original.tobytes()
 frames=[Image.frombytes('RGBA',im.size,bytes(v for px in im.getdata() for v in (px if px[3] else (0,0,0,0)))) for im in frames]
 sheet,doc=export_editor(frames,times,p)
 colors=sorted(set(px[:3] for f in frames for px in f.getdata() if px[3])); assert len(colors)<255
 table=[0,0,0]+[n for rgb in colors for n in rgb];table +=[0]*(768-len(table));lookup={rgb:i+1 for i,rgb in enumerate(colors)}
 gifs=[]
 for frame in frames:
  im=Image.new('P',frame.size);im.putpalette(table);im.putdata([lookup[a[:3]] if a[3] else 0 for a in frame.getdata()]);gifs.append(im)
 gifs[0].save(p/'preview.gif',save_all=True,append_images=gifs[1:],duration=times,loop=0,transparency=0,disposal=2,optimize=False)
 shutil.copyfile(R/c['sheet'],p/'previous.png')
 boxes=[f.getbbox() for f in frames];w,h=frames[0].size
 margin=min(min(a,b,w-x,h-y) for a,b,x,y in boxes);assert margin>=4,(k,margin)
 assert sum(times)==c['totalMs']
 save(p/'timing.json',dict(enemy=e,state=s,frameSize=[w,h],durationsMs=times,oldDurations=c['durationsMs'],oldSize=c['frameSize'],floorMargin=14,oldFloor=c['floor'],minimumMargin=margin,totalMs=sum(times),impactMs=c['impactMs'],identity=c['identitySHA256'],notes=notes,frameHashes=[proof(f) for f in frames],sheetSHA256=sha(sheet),editableSHA256=sha(doc)))

