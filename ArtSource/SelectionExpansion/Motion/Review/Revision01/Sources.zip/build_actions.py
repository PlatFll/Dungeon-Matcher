from build_common import *
from collections import deque
from functools import lru_cache
@lru_cache(None)
def raw(k,n):
 return Image.open(O/'Raw'/k/('%02d.png'%n)).convert('RGBA')
def clear(a,box):
 ImageDraw.Draw(a).rectangle(box,fill=(0,0,0,0))
def major(a):
 # Strip disconnected generation marks, retaining character and equipped object.
 pix=a.load();seen=set();components=[]
 for y in range(a.height):
  for x in range(a.width):
   if not pix[x,y][3] or (x,y) in seen:continue
   queue=[(x,y)];seen.add((x,y));part=[]
   for xx,yy in queue:
    part.append((xx,yy))
    for dx,dy in ((1,0),(-1,0),(0,1),(0,-1),(1,1),(-1,-1),(1,-1),(-1,1)):
     nx=xx+dx;ny=yy+dy
     if 0<=nx<a.width and 0<=ny<a.height and (nx,ny) not in seen and pix[nx,ny][3]:seen.add((nx,ny));queue.append((nx,ny))
   components.append(part)
 for part in sorted(components,key=len,reverse=True)[1:]:
  for pt in part:pix[pt]=(0,0,0,0)
 return a
def remap(im,ref):
 colors={p[:3] for p in ref.getdata() if p[3]};assignment={}
 for p in set(im.getdata()):
  if not p[3]:assignment[p]=(0,0,0,0);continue
  v=min(colors,key=lambda z:sum((x-y)**2 for x,y in zip(p,z)))
  assignment[p]=(*v,255)
 out=Image.new('RGBA',im.size);out.putdata([assignment[p] for p in im.getdata()]);return out
def part(im,poly):
 mask=Image.new('L',im.size);ImageDraw.Draw(mask).polygon(poly,fill=255);a=Image.new('RGBA',im.size);a.paste(im,mask=mask);return a
def rig(prop,origin,target,clockwise):
 dest=Image.new('RGBA',prop.size);dest.paste(prop.rotate(-clockwise,resample=Image.Resampling.NEAREST,center=(origin[0]+.5,origin[1]+.5)),(target[0]-origin[0],target[1]-origin[1]));return dest
def body_over(prop,body):
 prop.alpha_composite(body);return prop
def axe(k):
 ref=raw(k,0);grip=(68,105)
 prop=part(ref,[(54,96),(62,96),(63,100),(68,102),(68,106),(63,104),(63,107),(65,111),(63,113),(54,113)])
 clear(prop,(65,96,72,112))
 d=ImageDraw.Draw(prop)
 d.line((62,101,69,105),fill=(25,25,27,255),width=3);d.line((62,101,69,105),fill=(101,61,48,255))
 def f(n,hand,rot):
  a=raw(k,n).copy()
  if n==1:clear(a,(0,0,67,143))
  if n==2:clear(a,(0,0,159,70));clear(a,(0,70,78,73))
  if n==3:clear(a,(0,0,159,69));clear(a,(79,69,159,71))
  if n in (6,7):clear(a,(0,0,65 if n==6 else 67,143));clear(a,(0,0,159,72))
  # Slide the leading hand back down the shaft as the blow is loaded.
  reach={1:4,2:11,3:13,6:15,7:8}[n]
  ext=Image.new('RGBA',prop.size);dx,dy=-reach,-round(reach*.34)
  ImageDraw.Draw(ext).line((grip[0]+dx-2,grip[1]+dy-1,*grip),fill=(25,25,27,255),width=3)
  ImageDraw.Draw(ext).line((grip[0]+dx-2,grip[1]+dy-1,*grip),fill=(101,61,48,255))
  ext.alpha_composite(prop,(dx,dy))
  return body_over(rig(ext,grip,hand,rot),major(a))
 return [ref,f(1,(69,98),16),f(2,(79,75),72),f(3,(78,73),123),f(2,(79,75),75),f(1,(69,98),28),f(6,(69,112),-15),f(6,(69,112),-26),f(7,(69,112),-14),f(1,(69,98),8),ref],[70,60,55,85,30,20,90,50,55,65,100]
def pole(k):
 ref=raw(k,0);center=(64,102);prop=part(ref,[(51,67),(67,67),(67,78),(72,84),(72,87),(68,87),(66,90),(66,98),(65,99),(65,123),(66,125),(66,130),(62,130),(62,99),(62,94),(60,98),(52,94)])
 # replace pixels occluded by the front gauntlet with the continuing shaft.
 pdraw=ImageDraw.Draw(prop);clear(prop,(60,98,67,109))
 pdraw.rectangle((63,98,65,109),fill=ref.getpixel((63,111)));pdraw.line((64,98,64,109),fill=ref.getpixel((64,112)))
 def f(n,grip,ang):
  a=raw(k,n).copy()
  if n==0:
   clear(a,(0,0,71,87));clear(a,(0,88,66,98));clear(a,(0,99,60,105));clear(a,(0,107,66,143))
  elif n==7:
   clear(a,(0,0,57,143));clear(a,(0,0,62,94));clear(a,(0,0,59,97))
  else:clear(a,(0,0,56,143))
  return body_over(rig(prop,center,grip,ang),a)
 return [ref,f(0,(64,102),5),f(0,(64,102),-13),f(7,(60,101),-44),f(7,(60,101),-65),f(6,(58,99),-86),f(6,(58,99),-88),f(7,(60,101),-64),f(7,(60,101),-39),f(0,(64,102),-17),ref],[70,80,75,60,35,90,50,45,50,65,60]
def orc(k):
 ref=raw(k,0);l=ref.load()
 # Use the drawn fork and its gripping knuckles from the approved pose.
 fork=part(ref,[(44,73),(54,72),(55,74),(54,77),(53,79),(55,82),(53,86),(48,86),(47,81),(44,77)])
 def f(n,dx,pouch,stone=None):
  a=raw(k,n).copy()
  clear(a,(0,0,54,86))
  # frame six contains the projectile; the whole cast is hand timed below.
  clear(a,(0,0,45,76))
  arm=ImageDraw.Draw(a);gx=51+dx
  arm.line((gx,81,57,79),fill=l[50,83],width=4)
  arm.line((gx+1,80,57,78),fill=l[58,85],width=2)
  a.alpha_composite(fork,(dx,0));d=ImageDraw.Draw(a)
  # fork prongs -> pouch. Upper strand reads against cheek, lower crosses the scarf.
  d.line((46+dx,75,pouch[0],pouch[1]),fill=l[51,75]);d.line((51+dx,74,pouch[0],pouch[1]+1),fill=l[50,74])
  if pouch[0]>55:
   d.line((pouch[0],pouch[1]+1,pouch[0]+2,pouch[1]+2),fill=l[56,80],width=2)
  a=major(a);d=ImageDraw.Draw(a)
  if stone:
   x,y=stone
   d.polygon([(x-1,y),(x,y-1),(x+2,y-1),(x+3,y),(x+2,y+1),(x,y+1)],fill=(34,30,19,255))
   d.line((x,y,x+1,y-1),fill=(181,162,106,255));d.point((x+2,y),fill=(116,85,57,255))
  return a
 draw=f(7,-2,(61,76));rel=f(6,-3,(47,75),(40,75))
 return [ref,f(1,-1,(55,76)),f(7,-2,(58,76)),draw,rel,f(7,-2,(56,76)),draw,f(6,-3,(46,75),(38,75)),f(7,-1,(53,75)),ref],[75,85,90,70,60,70,50,55,60,65]
def shield(k):
 seq=[0,7,1,2,3,3,2,1,7,0];frames=[]
 for n in seq:
  a=major(raw(k,n).copy()) if n not in (0,7) else raw(k,n).copy()
  if n==3:
   clear(a,(70,64,110,81));clear(a,(72,60,110,64))
   tucked=part(raw(k,2),[(68,69),(71,68),(77,74),(77,81),(73,88),(68,89),(67,83),(66,78)])
   a.alpha_composite(tucked,(-3,0))
  frames.append(a)
 return frames,[80,65,80,95,95,45,65,55,45,55]
def medic(k):
 seq=[0,9,8,2,3,4,6,7,8,9,0];out=[]
 for j,n in enumerate(seq):
  a=raw(k,n).copy()
  if n in (2,3,4,6,7):
   # The white particle ring is detached from the opaque jewel and fingers.
   a=major(a)
   if n==2:
    clear(a,(0,0,56,60))
    jewel=major(raw(k,3).copy()).crop((0,0,57,61));a.paste(jewel,(0,0))
    a=major(a)
  if j in (5,6,7):
   # local jade highlight, confined to existing jewel pixels.
   for y in range(39,55):
    for x in range(38,56):
     r,g,b,t=a.getpixel((x,y))
     if t and g>r+23 and g>b and (x+y)%4<2:a.putpixel((x,y),(147,227,175,255))
  out.append(a)
 return out,[75,60,70,75,80,110,70,65,60,55,60]
def elf(k):
 seq=[0,1,7,2,3,4,5,6,7,0]
 return [raw(k,n) for n in seq],[90,55,75,100,95,45,40,60,50,70]
methods={'iceborn_axeman':(axe,'Two-handed overhead chop. The approved single axe travels as one piece through the draw, strike and recovery.'),
'nacre_halberdier':(pole,'A forward halberd thrust. The original head, shaft and butt rotate together around the forward gauntlet.'),
'orc_slinghunter':(orc,'Draw, release, redraw and release. The two stones leave the same fork at 320 and 500 ms.'),
'guild_bulwark':(shield,'One forward shield check from guard, with the off-hand mace following the torso.'),
'guild_chirurgeon':(medic,'The staff rises into a single open-hand healing cue. A highlight is confined to the jade head.'),
'elven_pathblade':(elf,'Low guard, straight forward blade extension and one recovery, with a short cape follow-through.')}
for c in edit:
 if c['state']=='idle':continue
 k=c['enemy']+'_'+c['state'];fn,notes=methods[c['enemy']];frames,times=fn(k)
 assert sum(times)==c['totalMs'],(k,sum(times))
 frames=[remap(f,frames[0]) if i not in (0,len(frames)-1) else f for i,f in enumerate(frames)]
 finish(c,frames,times,notes);print(k)

