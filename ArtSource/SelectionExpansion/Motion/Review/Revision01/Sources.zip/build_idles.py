from build_common import *
# local coordinates on the tight silhouette, measured against the approved identities.
# Each join intersects a flat material in the waist/knee. Weapons outside it travel
# rigidly with their hands, or stay planted along with the supporting arm.
def joint(e,x):
 if e=='guild_swordsman':return 46 if x<16 or x>=38 else 43
 if e=='guild_bulwark':return 48 if 16<=x<=24 or 33<=x<=41 else 60 if x<19 or x>=33 else 47
 if e=='guild_chirurgeon':return -5 if x<=11 else 44 if x>=36 else 47
 if e=='nacre_halberdier':return -5 if x<=16 else 51 if x<=22 else 48
 if e=='elven_pathblade':return 55 if x<25 or x>44 else 42
 if e=='orc_slinghunter':return 37 if x<10 else 25
 if e=='iceborn_axeman':return 58 if x<16 else 44
def idle_pose(im,e,lift,settle):
 if not (lift or settle):return im.copy()
 b=im.getbbox();result=Image.new('RGBA',im.size);src=im.load();dst=result.load()
 for x in range(b[0],b[2]):
  pivot=b[1]+joint(e,x-b[0])
  for y in range(b[1]-3,b[3]):
   # Two staggered pixel increments over the same breath, never a horizontal sway.
   sample=y+(lift if y<pivot else 0)+(settle if y<pivot-3 else 0)
   if 0<=sample<im.height: dst[x,y]=src[x,sample]
 if e=='elven_pathblade':
  # The sword overlaps the front boot. Separate its diagonal silver edge
  # from the boot so it can breathe with the grip while the foot stays put.
  l,t,_,_=b
  for row,start in [(46,17),(47,15),(48,13),(49,11),(50,10)]:
   for col in range(start,18):
    result.putpixel((l+col,t+row),im.getpixel((l+col,t+row)))
 return result
for c in edit:
 if c['state']!='idle':continue
 e=c['enemy'];im=Image.open(O/(e+'_idle_input.png')).convert('RGBA')
 poses=[(0,0),(1,0),(1,0),(1,1),(1,1),(1,0),(1,0),(0,0),(0,0)]
 if e=='orc_slinghunter':poses=[(0,0),(0,0),(1,0),(1,0),(1,0),(1,0),(0,0),(0,0),(0,0)]
 frames=[idle_pose(im,e,*p) for p in poses]
 finish(c,frames,[130]*9,'Grounded breathing drawn from the approved still. Nine timed exposures, pinned boot soles and one breath per cycle.')
print('Exported seven breathing loops through LibreSprite.')

