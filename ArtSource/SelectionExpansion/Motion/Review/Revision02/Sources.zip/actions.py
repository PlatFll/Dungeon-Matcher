from cels import *
from collections import deque
def raw(k,n):return loadim(O/'Raw'/k/('%02d.png'%n))
def rect_clear(im,box):ImageDraw.Draw(im).rectangle(box,fill=(0,0,0,0))
def rot(im,hinge,hand,a):
 return move(im.rotate(-a,Image.Resampling.NEAREST,center=(hinge[0]+.5,hinge[1]+.5)),hand[0]-hinge[0],hand[1]-hinge[1])
def contour(im):
 # Keep the single connected character from the new PixelLab take.
 p=im.load();seen=set();parts=[]
 for y in range(im.height):
  for x in range(im.width):
   if (x,y) in seen or not p[x,y][3]:continue
   group=[(x,y)];seen.add((x,y))
   for xx,yy in group:
    for dx,dy in ((1,0),(1,1),(0,1),(-1,1),(-1,0),(-1,-1),(0,-1),(1,-1)):
     pt=(xx+dx,yy+dy)
     if 0<=pt[0]<im.width and 0<=pt[1]<im.height and pt not in seen and p[pt][3]:seen.add(pt);group.append(pt)
   parts.append(group)
 for group in sorted(parts,key=len,reverse=True)[1:]:
  for pt in group:p[pt]=(0,0,0,0)
 return im
def lean(im,dx,dy,hip,knee):
 out=Image.new('RGBA',im.size)
 for y in range(im.height):
  weight=max(0,min(1,(knee-y)/(knee-hip)));ty=y+round(weight*dy);xx=round(weight*dx)
  if 0<=ty<im.height:out.paste(im.crop((0,y,im.width,y+1)),(xx,ty))
  if y and ty>last+1:out.paste(im.crop((0,y-1,im.width,y)),(xx,ty-1))
  last=ty
 return out
def axe_edge(im,x,y):
 # Relative to the abruptly cut vertical face of the approved hatchet.
 # The lower toe sweeps outward and rejoins the existing bright bevel.
 im=im.copy();d=ImageDraw.Draw(im)
 poly=lambda pts:[(x+px,y+py) for px,py in pts]
 d.polygon(poly([(2,-2),(4,-1),(3,3),(-1,5),(-2,7),(0,9),(5,10),(7,10),(6,12),(2,13),(-3,13),(-7,12),(-9,10),(-10,8),(-10,4),(-9,2),(-8,4),(-6,4),(-3,3),(0,0)]),fill=(5,5,7,255))
 d.polygon(poly([(1,0),(3,-1),(2,2),(-2,5),(-3,7),(-2,9),(2,10),(5,11),(1,12),(-3,12),(-6,11),(-8,9),(-9,7),(-9,4),(-7,5),(-4,5)]),fill=(94,106,114,255))
 d.polygon(poly([(1,0),(3,0),(2,2),(-2,5),(-3,7),(-5,7),(-7,6),(-4,5)]),fill=(47,60,72,255))
 d.line(poly([(-9,5),(-9,8),(-7,10),(-4,12),(1,12),(5,11)]),fill=(183,163,147,255),width=1)
 d.line(poly([(-9,7),(-8,9),(-5,11)]),fill=(227,209,192,255),width=1)
 return im
def axeattack(k):
 # Preserve the reviewed chop and its original PixelLab body cels. Complete the
 # single blade on the prop BEFORE rotation, including guard and final recovery.
 ref=raw(k,0);repaired=axe_edge(ref,55,99);hinge=(68,105)
 prop=masked(repaired,[(43,94),(62,94),(64,101),(69,103),(69,106),(63,104),(64,109),(65,115),(43,115)])
 rect_clear(prop,(65,96,72,112));d=ImageDraw.Draw(prop);d.line((62,101,69,105),fill=(25,25,27,255),width=3);d.line((62,101,69,105),fill=(101,61,48,255))
 def frame(n,hand,a):
  body=raw(k,n).copy()
  if n==1:rect_clear(body,(0,0,67,143))
  if n==2:rect_clear(body,(0,0,159,70));rect_clear(body,(0,70,78,73))
  if n==3:rect_clear(body,(0,0,159,69));rect_clear(body,(79,69,159,71))
  if n in (6,7):rect_clear(body,(0,0,65 if n==6 else 67,143));rect_clear(body,(0,0,159,72))
  body=contour(body);reach={1:4,2:11,3:13,6:15,7:8}[n];dx=-reach;dy=-round(reach*.34)
  ext=Image.new('RGBA',prop.size);d=ImageDraw.Draw(ext);d.line((66+dx,104+dy,68,105),fill=(25,25,27,255),width=3);d.line((66+dx,104+dy,68,105),fill=(101,61,48,255));ext.alpha_composite(prop,(dx,dy))
  out=rot(ext,hinge,hand,a);out.alpha_composite(body);return remap(out,ref)
 frames=[repaired,frame(1,(69,98),16),frame(2,(79,75),72),frame(3,(78,73),123),frame(2,(79,75),75),frame(1,(69,98),28),frame(6,(69,112),-15),frame(6,(69,112),-26),frame(7,(69,112),-14),frame(1,(69,98),8),repaired]
 return frames,[70,60,60,80,30,20,90,50,60,60,100]
def staff(k):
 ref=loadim(O/(k+'_input.png'));l,t,_,_=ref.getbbox()
 def pos(poly):return [(l+x,t+y) for x,y in poly]
 rod=masked(ref,pos([(0,3),(8,3),(9,12),(7,17),(14,56),(14,58),(11,58),(9,43),(7,32),(4,17),(0,13)]))
 hand=masked(ref,pos([(7,30),(11,30),(12,32),(11,36),(8,36),(7,34)]))
 # Separate the raised arm from the sleeve and facing arm of the resting body.
 region=pos([(5,29),(14,29),(18,26),(20,29),(17,34),(14,37),(7,38),(5,35)])
 blank=erase(erase(ref,rod),masked(ref,region))
 d=ImageDraw.Draw(blank)
 d.polygon(pos([(7,36),(13,34),(17,31),(16,36),(12,43),(10,51),(8,52),(8,45)]),fill=(40,54,62,255))
 def f(height,power):
  if not height:return ref.copy()
  im=blank.copy();sty=t+33-height;hx=l+9;shoulder=(l+20,t+29);el=(l+15,t+32-height//2)
  d=ImageDraw.Draw(im)
  d.line((shoulder,el,(hx+1,sty)),fill=(28,24,24,255),width=6)
  d.line((shoulder,el,(hx+1,sty)),fill=(175,160,139,255),width=4)
  d.line(((l+19,t+28),(el[0],el[1]-1),(hx+1,sty-1)),fill=(234,218,192,255),width=2)
  im.alpha_composite(rod,(0,-height));im.alpha_composite(hand,(0,-height))
  if power:
   # Attach the light to the lifted jewel. Its stepped halo changes radius
   # and luminance while the face, sleeves and free hand remain still.
   cx=l+4;cy=t+9-height;d=ImageDraw.Draw(im)
   if power>=2:
    radius=5 if power==2 else 7
    diamond=[(cx,cy-radius),(cx+radius-2,cy),(cx,cy+radius),(cx-radius+2,cy)]
    d.polygon(diamond,fill=(42,116,111,255))
    d.polygon([(cx,cy-radius+2),(cx+radius-4,cy),(cx,cy+radius-2),(cx-radius+4,cy)],fill=(97,205,176,255))
    im.alpha_composite(rod,(0,-height))
   for ax,ay,rr in [(0,-5,power),(-4,-1,power),(4,0,power)]:
    d.line((cx+ax,cy+ay,cx+ax+(0 if ax==0 else (1 if ax>0 else -1))*rr,cy+ay+(-rr if ax==0 else 0)),fill=(90,175,157,255),width=1)
   d.polygon([(cx,cy-3),(cx+2,cy-1),(cx+1,cy+2),(cx-1,cy+3),(cx-2,cy)],fill=(94,202,170,255));d.line((cx,cy-2,cx-1,cy+1),fill=(230,255,219,255),width=1 if power==1 else 2)
   if power==3:d.point((cx,cy),fill=(255,255,241,255))
  return contour(im)
 levels=[(0,0),(2,0),(5,0),(9,0),(12,1),(13,2),(13,3),(13,2),(12,1),(8,0),(4,0),(1,0),(0,0)]
 return [f(*v) for v in levels],[70,60,60,60,60,50,100,60,40,60,50,50,60]
def mace(k):
 ref=raw(k,0)
 def frame(n,dx=0,dy=0):
  a=remap(raw(k,n),ref)
  if n==3:rect_clear(a,(35,69,41,83))
  return lean(a,dx,dy,78,96) if dx or dy else a
 # Drawn contact uses the PixelLab raised forearm and the actual mace head.
 # Shield stays on its original side as the leading hand carries the blow.
 def contact(low):
  a=frame(2);rect_clear(a,(0,0,39,96))
  # Rear half of the overlong generated handle, below the wrist, is covered
  # by the original tunic and its diagonal leather strap.
  d=ImageDraw.Draw(a);d.line((41,77,49,84),fill=(42,30,28,255),width=3)
  d.line((40,75,34,75+low,26,72+low),fill=(17,13,15,255),width=4);d.line((40,75,34,75+low,26,72+low),fill=(89,65,49,255),width=2)
  head=masked(ref,[(32,88),(35,84),(40,84),(42,87),(41,92),(38,95),(34,94),(32,92)])
  a.alpha_composite(head,(26-37,72+low-90));return lean(a,-3,1,76,96)
 return [ref,frame(1),frame(2),frame(3),frame(3,1,-1),frame(2,-1),contact(6),contact(9),frame(1,-1,1),frame(1),ref],[70,60,60,60,50,20,90,40,70,60,100]
def pole(k):
 ref=raw(k,0);piv=(64,102)
 prop=masked(ref,[(51,67),(67,67),(67,78),(72,83),(73,87),(68,88),(66,90),(66,123),(67,125),(67,130),(62,130),(62,96),(60,98),(52,94)])
 rect_clear(prop,(60,98,68,109));d=ImageDraw.Draw(prop);d.rectangle((63,98,65,109),fill=ref.getpixel((63,111)));d.line((64,98,64,109),fill=ref.getpixel((64,112)))
 # Retain real shoulder, gauntlet, elbow and coat drawings from the new take.
 def cut(n,fp,ang,dx,dy):
  a=remap(raw(k,n),ref)
  rect_clear(a,(0,0,159,66));rect_clear(a,(0,0,fp[0]-3,143));rect_clear(a,(110,0,159,143))
  rect_clear(a,(0,66,68,90));a=contour(a)
  if n in (4,7):
   for px in range(fp[0]+4,71):
    yy=round(fp[1]+(px-fp[0])*.63)
    for py in range(yy-2,yy+3):
     if py>102:a.putpixel((px,py),(0,0,0,0))
  weapon=rot(prop,piv,fp,ang);weapon.alpha_composite(a)
  return lean(weapon,dx,dy,101,128)
 def high(ang,weight):
  a=remap(raw(k,2),ref)
  # Replace the foreshortened generated blade overlapping the crest with the
  # same hooked blade as the guard. Restore the helmet beneath that overlap.
  rect_clear(a,(0,0,159,73));rect_clear(a,(0,0,65,123))
  rect_clear(a,(66,68,78,78))
  helmet=masked(ref,[(70,68),(96,66),(100,79),(95,86),(92,92),(83,96),(77,94),(74,88),(74,84),(70,83)])
  a.alpha_composite(helmet)
  weapon=rot(prop,piv,(69,82),ang);weapon.alpha_composite(a)
  return lean(weapon,weight,-1,102,128)
 seq=[ref,raw(k,1),high(24,1),high(35,2),
      cut(4,(57,99),-34,0,0),cut(4,(57,99),-62,-1,1),cut(5,(58,103),-91,-3,2),
      cut(6,(63,108),-111,-3,3),cut(6,(63,108),-99,-2,2),cut(7,(60,103),-56,0,1),raw(k,1),ref]
 seq=[remap(a,ref) if j not in (0,len(seq)-1) else a for j,a in enumerate(seq)]
 return seq,[60,50,70,70,30,40,90,60,50,50,50,60]
def sling(k):
 ref=raw(k,0)
 loaded=revframes(k)[3];half=revframes(k)[2]
 # Fork and string stay lowered after the single release. The generated
 # outward rear arm and lifted front foot are the balance catch.
 def fall(n,dx,dy):
  a=raw(k,n).copy();a=contour(a);return remap(lean(a,dx,dy,83,96),ref)
 shot=fall(4,1,-1)
 def pebble(im,x,y):
  im=im.copy();d=ImageDraw.Draw(im);d.polygon([(x-2,y),(x,y-2),(x+2,y-1),(x+2,y+1),(x-1,y+1)],fill=(34,30,19,255));d.line((x-1,y,x+1,y-1),fill=(181,162,106,255));return im
 return [ref,half,loaded,pebble(shot,41,79),pebble(shot,32,78),pebble(fall(5,2,-1),20,77),fall(5,2,0),fall(7,1,0),ref],[80,100,140,30,30,30,80,90,100]
if __name__=='__main__':
 for k,fn,note in [('guild_bulwark_basic',mace,'The shield covers his flank while the mace rises and lands a short downward strike.'),('guild_chirurgeon_special',staff,'She raises the staff, holds its glowing jade tip at the heal, then lowers it.'),('iceborn_axeman_basic',axeattack,'The complete curved toe and bright bevel are visible in the opening guard and rotate with the axe.'),('nacre_halberdier_basic',pole,'A high guard leads into one sweeping hook cut. The Halberdier dips into the follow-through and recovers behind the blade.'),('orc_slinghunter_basic',sling,'One pebble leaves the fork. The orc rocks back, lifts a foot and catches his balance.')]:
  frames,times=fn(k);assert sum(times)==(780 if k.endswith('special') else 680),(k,sum(times));finish(k,frames,times,note,{'healMs':360} if k.endswith('special') else {'impactMs':320,**({'projectiles':1,'releaseMs':[320]} if k.startswith('orc') else {})})

