from pathlib import Path
from PIL import Image,ImageDraw,ImageFilter
import json,math,os,sys,re,shutil,hashlib
W=Path(os.environ['DUNGEON_MATCHER_PROJECT'])
O=Path(__file__).resolve().parent

M=W/'ArtSource/SelectionExpansion/Motion'
P=M/'Review/Revision01'
V1=P/'Clips'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,o):p.write_text(json.dumps(o,indent=2)+'\n',encoding='utf-8')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def loadim(p):return Image.open(p).convert('RGBA')
def tight(im):return im.crop(im.getbbox())


import struct,subprocess,os
libre=os.environ.get('LIBRESPRITE','libresprite')
def proof(im):return hashlib.sha256(im.tobytes()).hexdigest()
def export_editor(cels,times,folder):
 folder.mkdir(exist_ok=True,parents=True);doc=folder/'source.aseprite'
 # Feed the lossless RGBA sequence through the native editor. A temporary ASE file
 # permits exact durations, including a held pose with unchanged pixels.
 def pack(fmt,*v):return struct.pack('<'+fmt,*v)
 import zlib
 def chunk(kind,payload):return pack('IH',len(payload)+6,kind)+payload
 def string(x):return pack('H',len(x))+x
 layer=chunk(0x2004,pack('HHHHHHB',3,0,0,0,0,0,255)+bytes(3)+string(b'Character'))
 frames=[]
 for i,im in enumerate(cels):
  cel=chunk(0x2005,pack('HhhBH',0,0,0,255,2)+bytes(7)+pack('HH',*im.size)+zlib.compress(im.tobytes()))
  body=(layer if i==0 else b'')+cel
  frames.append(pack('IHHH',len(body)+16,0xF1FA,2 if i==0 else 1,times[i])+bytes(6)+body)
 header=bytearray(128);struct.pack_into('<IHHHHHIH',header,0,128+sum(map(len,frames)),0xA5E0,len(frames),*cels[0].size,32,1,times[0]);header[34:36]=bytes([1,1])
 src=folder/'registered.ase';src.write_bytes(header+b''.join(frames))
 subprocess.run([libre,'-b',str(src),'--save-as',str(doc)],check=True,capture_output=True)
 png=folder/'sheet.png';subprocess.run([libre,'-b',str(doc),'--sheet-type','horizontal','--sheet',str(png)],check=True,capture_output=True)
 out=Image.open(png).convert('RGBA');w,h=cels[0].size;assert out.size==(w*len(cels),h),(out.size,len(cels))
 blob=doc.read_bytes();offset=128;actual=[]
 for i,im in enumerate(cels):
  assert out.crop((i*w,0,(i+1)*w,h)).tobytes()==im.tobytes()
  actual.append(struct.unpack_from('<H',blob,offset+8)[0]);offset+=struct.unpack_from('<I',blob,offset)[0]
 assert actual==times
 src.unlink();return png,doc

