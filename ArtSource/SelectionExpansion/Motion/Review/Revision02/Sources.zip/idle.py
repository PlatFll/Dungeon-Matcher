from cels import *
# Coordinates are local to each approved still. The moving head stops at the jaw
# or gorget. Equipment, collar and boot silhouettes remain on the breathing cel.
actors={
'elven_pathblade':dict(head=[(0,-2),(34,-2),(34,12),(29,16),(34,17),(33,21),(25,19),(21,23),(16,25),(8,25),(5,22),(1,20)],tuft=[(18,1),(25,1),(29,4),(31,9),(25,8),(23,6),(21,7)],eyes=[(8,16,10,18),(15,15,17,18)],skin=(12,19),line=(9,17),cycles=3,blink=1960,phase=1),
'guild_bulwark':dict(head=[(14,-1),(46,-2),(46,16),(42,20),(41,21),(35,23),(31,25),(24,26),(19,23),(17,20),(16,15)],tuft=[(19,2),(29,-2),(36,-1),(38,3),(32,5),(25,4),(20,7),(17,8)],eyes=[(20,17,21,19),(28,17,32,19)],skin=(23,20),line=(21,17),cycles=4,blink=2270,phase=2),
'guild_chirurgeon':dict(head=[(12,-1),(44,-1),(44,23),(39,22),(36,19),(32,23),(29,25),(19,25),(15,21),(14,15)],tuft=[(33,0),(43,-1),(43,11),(40,11),(36,8),(34,7)],eyes=[(17,15,18,17),(25,15,28,17)],skin=(21,18),line=(18,16),cycles=3,blink=1600,phase=2),
'guild_swordsman':dict(head=[(12,-2),(46,-1),(47,21),(44,23),(41,24),(39,27),(34,28),(32,30),(23,30),(17,28),(15,24),(15,18),(11,17)],tuft=[(12,5),(20,1),(25,0),(31,-1),(33,3),(26,4),(23,6),(17,6),(13,9)],eyes=[(18,19,20,22),(27,19,32,22)],skin=(24,22),line=(19,20),cycles=3,blink=2360,phase=0),
'iceborn_axeman':dict(head=[(16,-2),(39,-1),(41,8),(38,13),(38,16),(35,20),(33,23),(30,27),(24,29),(18,27),(17,24),(18,19),(17,15)],tuft=[(18,22),(20,23),(26,25),(32,21),(33,22),(29,27),(25,29),(20,27)],eyes=[(20,16,22,17),(27,16,29,17)],skin=(25,18),line=(21,17),cycles=3,blink=1400,phase=1),
'nacre_halberdier':dict(head=[(20,-2),(48,-2),(47,14),(42,17),(41,20),(39,24),(35,26),(29,27),(24,26),(22,22),(21,17)],tuft=[(31,0),(44,-2),(47,10),(41,13),(37,11),(37,7),(32,9)],eyes=[],cycles=4,blink=2700,phase=0),
'orc_slinghunter':dict(head=[(9,-1),(24,-1),(29,3),(28,8),(25,9),(24,12),(21,13),(13,13),(9,11),(8,9)],tuft=[(20,3),(24,4),(28,3),(28,7),(23,9),(22,8)],eyes=[(11,7,13,8),(16,6,18,8)],skin=(14,5),line=(17,7),cycles=3,blink=2200,phase=2)}
def blink(im,e,a,level):
 if not level:return
 d=ImageDraw.Draw(im)
 if e=='nacre_halberdier':
  # A single exposed pearl eye sits inside the visor. Hide that light only.
  for x,y in [(33,19),(34,19),(33,20)] if level==2 else [(33,19),(34,19)]:
   d.point((x,y),fill=im.getpixel((30,22)))
  return
 skin=im.getpixel(a['skin']);ink=im.getpixel(a['line'])
 for x0,y0,x1,y1 in a['eyes']:
  d.rectangle((x0,y0,x1,y1 if level==2 else y0),fill=skin)
  if level==2:d.line((x0,y1-1,x1,y1-1),fill=ink)
def build(e):
 a=actors[e];k=e+'_idle';base=revframes(k);orig=loadim(O/(k+'_input.png'));l,t,r,b=orig.getbbox()
 duration=1170*a['cycles'];blinkstart=a['blink'];cuts=set(range(0,duration+1,130))|{blinkstart,blinkstart+40,blinkstart+120,blinkstart+160}
 times=sorted(cuts);frames=[];delays=[]
 for ts,end in zip(times,times[1:]):
  beat=(ts//130)%9;cycle=ts//1170
  im=base[beat].copy();lift=[0,1,1,2,2,1,1,0,0][beat] if e!='orc_slinghunter' else [0,0,1,1,1,1,0,0,0][beat]
  im0=Image.new('RGBA',(r-l+10,b-t+10));im0.paste(im,(-l+4,-t+4+lift))
  def poly(p):return [(x+4,y+4) for x,y in p]
  head=masked(im0,poly(a['head']));brow=Image.new('RGBA',im0.size);inner=Image.new('RGBA',(r-l,b-t));inner.paste(head,(-4,-4))
  u=ts-blinkstart;level=1 if 0<=u<40 or 120<=u<160 else 2 if 40<=u<120 else 0
  blink(inner,e,a,level)
  dx=(-1 if (cycle+a['phase'])%3!=1 else 1) if 2<=beat<=5 else 0
  dy=-1 if beat in (3,4) else 0
  # Use the original head as a backing wherever a tuft shifts over the scalp.
  if beat in (4,5,6):
   tuft=masked(inner,a['tuft']);inner=patch_layer(inner,a['tuft'],1 if dx<=0 else -1,0)
  brow.paste(inner,(4,4))
  if dx or dy:
   im0=patch_layer(im0,poly(a['head']),dx,dy)
  headmask=masked(brow,poly(a['head']));im0.alpha_composite(headmask,(dx,dy))
  # A shifted tuft may extend a pixel beyond the primary head outline.
  if beat in (4,5,6):
   tuft=masked(brow,[(x+4+(1 if dx<=0 else -1),y+4) for x,y in a['tuft']]);im0.alpha_composite(tuft,(dx,dy))
  out=Image.new('RGBA',im.size);out.paste(im0,(l-4,t-4-lift))
  if ts==0 or end==duration:out=orig.copy()
  if e=='iceborn_axeman':
   from actions import axe_edge
   out=axe_edge(out,l,t+26-lift)
  if frames and out.tobytes()==frames[-1].tobytes():delays[-1]+=end-ts
  else:frames.append(out);delays.append(end-ts)
 finish(k,frames,delays,{'nacre_halberdier':'Grounded breathing, a crest that follows the head and a brief eye closure inside the visor.','orc_slinghunter':'A short head turn, ear movement and a quick blink over the planted stance.','iceborn_axeman':'A slow head shift, beard follow-through and a brief blink with the axe resting in his hands.'}.get(e,'Grounded breathing with a small head turn, delayed hair movement and a brief blink.'),{'blinkStartMs':blinkstart,'closedMs':80})
if __name__=='__main__':
 for e in actors:build(e)

