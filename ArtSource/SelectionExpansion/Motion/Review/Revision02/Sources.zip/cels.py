from artlib import *
def move(img,dx=0,dy=0):
 out=Image.new('RGBA',img.size);out.alpha_composite(img,(dx,dy));return out
def masked(im,poly):
 m=Image.new('L',im.size);ImageDraw.Draw(m).polygon(poly,fill=255);out=Image.new('RGBA',im.size);out.paste(im,mask=m);return out
def erase(im,mask):
 a=im.copy();a.paste((0,0,0,0),mask=mask.getchannel('A'));return a
def remap(im,ref):
 colors={p[:3] for p in ref.getdata() if p[3]};memo={}
 for p in set(im.getdata()):
  memo[p]=(*min(colors,key=lambda c:sum((v-x)**2 for v,x in zip(c,p))),255) if p[3]>127 else (0,0,0,0)
 out=Image.new('RGBA',im.size);out.putdata([memo[p] for p in im.getdata()]);return out
def patch_layer(im,poly,dx,dy):
 if dx==0 and dy==0:return im
 cut=masked(im,poly);body=erase(im,cut);pix=body.load();src=body.copy().load()
 # Extend only covered pixels at an internal joint. Outside edges remain transparent.
 for x in range(max(0,cut.getbbox()[0]),cut.getbbox()[2]):
  for y in range(cut.getbbox()[1],cut.getbbox()[3]):
   if not cut.getpixel((x,y))[3]:continue
   for sx,sy in [(0,1),(1,0),(-1,0),(0,-1),(1,1),(-1,1),(0,2),(2,0),(-2,0)]:
    xx,yy=x+sx,y+sy
    if 0<=xx<im.width and 0<=yy<im.height and src[xx,yy][3]:
     pix[x,y]=src[xx,yy];break
 body.alpha_composite(cut,(dx,dy));return body
def revframes(k):
 t=read(V1/k/'timing.json');w,h=t['frameSize'];sh=loadim(V1/k/'sheet.png')
 return [sh.crop((i*w,0,(i+1)*w,h)) for i in range(len(t['durationsMs']))]
def finish(k,frames,times,note,events=None):
 p=O/'Clips'/k;p.mkdir(parents=True,exist_ok=True)
 for im in frames:
  im.paste((0,0,0,0),mask=im.getchannel('A').point(lambda a:255 if not a else 0))
 assert frames[0].tobytes()==frames[-1].tobytes(),k
 assert len(times)==len(frames) and all(t>0 and not t%10 for t in times)
 sheet,doc=export_editor(frames,times,p)
 pal=sorted({c[:3] for im in frames for c in im.getdata() if c[3]});assert len(pal)<=255
 table=[0,0,0]+[v for rgb in pal for v in rgb];table+=[0]*(768-len(table));indices={rgb:i+1 for i,rgb in enumerate(pal)};gifs=[]
 for im in frames:
  g=Image.new('P',im.size);g.putpalette(table);g.putdata([indices[p[:3]] if p[3] else 0 for p in im.getdata()]);gifs.append(g)
 gifs[0].save(p/'preview.gif',save_all=True,append_images=gifs[1:],duration=times,loop=0,transparency=0,disposal=2,optimize=False)
 t=read(V1/k/'timing.json');w,h=frames[0].size;boxes=[f.getbbox() for f in frames];t.update(oldDurations=t['durationsMs'],oldSize=t['frameSize'],oldFloor=t['floorMargin'],frameSize=[w,h],durationsMs=times,totalMs=sum(times),minimumMargin=min(min(a,b,w-c,h-d) for a,b,c,d in boxes),notes=note,events=events or {},frameHashes=[proof(f) for f in frames],sheetSHA256=sha(sheet),editableSHA256=sha(doc))
 assert t['minimumMargin']>=4
 save(p/'timing.json',t);shutil.copyfile(V1/k/'sheet.png',p/'previous.png')

